Follow the exact steps to compile and execute the Server and Client application:
1.	At first go to the src folder (if not already in it) form where you can open the application as follows
2.	At first open the terminal and then run the command to compile the file using:> javac serverthread.java
3.	Then for compiling the client application type :> javac client.java
4.	Then run the server application by :> java TCPServer
	This will initiate the server.
5.	Now open the new window and type :>	java TCPClient
	You can open as many clients as you want using the same above command on different terminals.
6.	When you want to close the client you can just close it by exiting the terminal or using ctrl+c.